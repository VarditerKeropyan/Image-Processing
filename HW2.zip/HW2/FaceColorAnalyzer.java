import ij.IJ;
import ij.ImagePlus;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import java.util.TreeSet;

public class FaceColorAnalyzer implements PlugIn {

    @Override
    public void run(String arg) {
        // Path to the folder containing images
        String folderPath = "/Users/varditerkeropyan/Documents/Image Processing/HW2/face/";
        
        // TreeSet to store unique non-black colors
        TreeSet<Integer> colorSet = new TreeSet<>();

        // Load all images and collect unique non-black colors
        for (String filename : new java.io.File(folderPath).list()) {
            if (filename.toLowerCase().endsWith(".jpg") || filename.toLowerCase().endsWith(".png")) {
                ImagePlus imp = IJ.openImage(folderPath + filename);
                if (imp == null) continue;
                ImageProcessor ip = imp.getProcessor();
                int width = ip.getWidth();
                int height = ip.getHeight();

                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        int rgb = ip.getPixel(x, y);
                        int red = (rgb >> 16) & 0xff;
                        int green = (rgb >> 8) & 0xff;
                        int blue = rgb & 0xff;

                        if (red != 0 || green != 0 || blue != 0) { // Non-black
                            int color = (red << 16) | (green << 8) | blue;
                            colorSet.add(color);
                        }
                    }
                }
            }
        }

        // Arrays to store the computed values for each G
        int[] count = new int[256];
        double[] min = new double[256];
        double[] max = new double[256];
        double[] mean = new double[256];
        double[] mean2 = new double[256];

        // Initialize min values to a large number
        for (int i = 0; i < 256; i++) {
            min[i] = Double.MAX_VALUE;
        }

        // Compute the required quantities for each G
        for (int color : colorSet) {
            int red = (color >> 16) & 0xff;
            int green = (color >> 8) & 0xff;
            int blue = color & 0xff;

            double rbHalf = (red + blue) / 2.0;
            count[green]++;
            min[green] = Math.min(min[green], rbHalf);
            max[green] = Math.max(max[green], rbHalf);
            mean[green] += rbHalf;
            mean2[green] += rbHalf * rbHalf;
        }

        // Finalize mean and mean2 calculations
        for (int g = 0; g < 256; g++) {
            if (count[g] > 0) {
                mean[g] /= count[g];
                mean2[g] /= count[g];
            } else {
                min[g] = 0; // No values for this G
                max[g] = 0;
            }
        }

        // Output the results
        for (int g = 0; g < 256; g++) {
            //IJ.log("G = " + g + ": count = " + count[g] + ", min = " + min[g] + ", max = " + max[g] + ", mean = " + mean[g] + ", mean2 = " + mean2[g]);
            //IJ.log("" + g);
            //IJ.log("" + count[g]);
            // IJ.log("" + min[g]);
            // IJ.log("" + max[g]);
            // IJ.log("" + mean[g]);
             IJ.log("" + mean2[g]);
        }
    }
}
